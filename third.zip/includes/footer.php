<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2020 Brought to You By <a href="https://github.com/willowusu">William Owusu</a></strong>
    </div>
</footer>